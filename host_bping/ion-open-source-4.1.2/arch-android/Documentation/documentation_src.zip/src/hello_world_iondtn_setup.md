# IonDTN Setup

Besides creating an own application, we also need to have the *IonDTN* provider application installed and set up on the Android device.

## IonDTN installation

If you have the IonDTN application already installed on your device, just make sure that the app version is compatible to this documentation. Otherwise you might use the provided interface in a wrong way.

If you haven't installed the *IonDTN* application yet, you probably want to build and deploy it yourself. In order to do so, just open the `IonDTN` project located in `arch_android` directory of the ION-DTN archive in Android Studio. Due to Android Studio's feature detection, it will ask you for permission to install all required SDKs and NDKs. Please install all these packages, connect your Android device and then proceed by pressing the `Run 'app'` icon in the toolbar:

![run app](./resources/run_app.png)

Android Studio will build the app, install it on your device and open it.

You should be greeted by the following screen of the application setup:

![iondtn setup welcome](./resources/ion_dtn_setup_welcome.png)

## IonDTN setup

Now we have to configure the app and the underlying *ION-DTN* instance.

### Node Number

First, we have to select a node number:

![iondtn setup select node number](./resources/ion_dtn_setup_node_number.png)

Just choose *"1"* in order to ensure compatibility with the configuration file used in all subsequent steps.

### Setup Type

After pressing the arrow button, you have to select one of the two setup options:

![iondtn setup select node number](./resources/ion_dtn_setup_init_selection.png)

The options are characterized as follows:
- **Empty Configuration**: The all necessary daemons and services are started, but initially no *contacts*, *ranges*, etc. are created. The user has to use the *IonDTN's* GUI to set these up.
- **Configuration based on `.rc` file:** The user can select an `.rc` file during the setup process and the configuration of that file is copied into the app configuration. Only the node number is overwritten. This overwriting allows the usage of the same configuration file for multiple devices.

For our *"Hello World"* project, please choose `"Setup configuration based on file"` and proceed by taping on the arrow button.

### Permission

Depending on the Android version of your device and your security settings, you might be asked to give *IonDTN* the permission to access the devices external memory (which is the the memory that is accessible by the user and all other applications). Grant the permission and tap the arrow button to proceed.

### Select Setup File

![iondtn setup select path](./resources/ion_dtn_setup_select_path.png)

In the upcoming dialog you have to select an appropriate configuration file. For the purpose of the *"Hello World"* project, please modify the linked configuration file [`android_node.rc`](./resources/code/android_node.rc), copy it to your device and select it in the file selection dialog.

The following modifications are necessary:
- Assign a static IP address to your device (or use the already via DHCP assigned one, however, this might cause malfunction when a new IP address is assigned).
- Update both the in-/outducts and the plan details to correspond to the topology and your IP addresses.

The topology for our test is as follows:

![iondtn setup topology](./resources/topology_hello_world.png)

You can use the linked [`pc_node.rc`](./resources/code/pc_node.rc) file to setup an *ION-DTN* file on your development machine or another computer.

Please refer to the *ION-DTN* configuration for details on how to configure an ION node.

Again, tap the arrow button in the *IonDTN* application and the app perform the setup of the node.

### Finish setup

If the setup succeeded (i.e. the configuration file was consistent), you will see the following screen:

![iondtn setup complete](./resources/ion_dtn_setup_complete.png)

Congratulations, IonDTN Setup is now complete. Click on the button to leave setup and you will be redirected to the main status screen of the application.

## Start/Stop ION-DTN

![iondtn status fragment](./resources/ion_dtn_status_fragment.png)

On the main status screen you can start and stop the underlying *ION-DTN* instance. Just press the switch in the top right corner and *ION-DTN* will start. The startup process will take some time, but you will get notified when the instance is started and ready to use. You can also follow the log messages that appear in the log output view whenever functions and deamons are invoked. Besides the in-app status information there is also a persistent notification.

The persistent notification serves two purposes:
1. It ensures that the user is aware that *ION-DTN* is running in the background and that takes some resources.
2. It prevents the service and the *ION-DTN* instance to get killed by the Android operating system. Android has a  rigorous resource management and stops applications that are running in the background and still claiming memory and cpu cycles. However, in the case of the *IonDTN* provider application the app has to run continuously to ensure that bundles can be received at any time. By displaying the notification to the user (i.e. *"starting the service of the application in the foreground"* in Android's terms) the likelihood of the Android OS killing *IonDTN* is negligible.

**Please start the ION instance before continuing in order to use it with *DtnHelloWorld*.**

## In-App configuration

After starting the *ION-DTN* instance, you can swipe right from the left side of the screen to open up the main navigation drawer. In this drawer you can select the various configuration elements to review and change the configuration of the node.

![iondtn navigation drawer](./resources/ion_dtn_nav_drawer.png)

Although not necessary for our project, you can have a look what options are available there. Furthermore, in the *"Settings"* menu you can change some default values and reset the application if necessary (i.e. to load a different initalization `.rc` file).
