# Getting Started: "Hello World"

In this introductory chapter we will create a small Android application that follows the ["Hello World"](https://en.wikipedia.org/wiki/%22Hello,_World!%22_program) tradition and sends a bundle with the string payload "Hello World!" to a node selected by the user.

> **Note:** This tutorial assumes some prior knowledge about the programming of Android applications and will mostly just cover the relevant parts in context of the IonDTN interaction. If you are new to Android programming, please refer to the (very good) tutorials at the [Android Website](https://developer.android.com/training/index.html). Besides the details of the Java programming language, Android has some special patterns and restrictions that are worth knowing.

In order to accomplish this task, the app has to work through a few subtasks. These tasks are shown in the following diagram:

<center><img src="./resources/subtasks_hello_world.png" height="400" align="center" /></center>

- First, we have to create an GUI that can take the destination EID as an user input.
- Then, we have to get a handle for the *IonDTN's* `BundleService` and then bind to that service using the handle.
- Whenever the user triggers an event by pressing an button in the GUI, we use the bound service to send out a bundle to the defined destination EID.
