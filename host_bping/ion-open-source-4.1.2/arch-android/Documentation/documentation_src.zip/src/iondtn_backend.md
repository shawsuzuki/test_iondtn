# Backend

The backend of the IonDTN application is consisting of 4 components. These components serve the purpose of providing a particular service/operation to other components of the application. However, in the sense of Android, these components are not regarded and registered as **Services**. Instead they are implemented as Java classes that are either accessed static or are instantiated by the client component.

### ConfigFileManager

The `ConfigFileManager` is used during the initialization process and creates all necessary configuration files to start the ION-DTN instance for the first time. The `ConfigFileManager` supports the two initialization modes `empty` and `custom`. For `empty` the file manager simply creates empty configuration files that just contain the startup commands for the deamons. When the user selects a `custom` initialization and provides a `.rc` configuration file, the `ConfigFileManager` parses this file and creates a one-time startup configuration based on it. This first-time startup will setup the node as specified in the config file. From the second startup onwards, a `empty` configuration file just containing the startup commands for the deamons will be used.

### IpndFileUpdater

The `IpndFileUpdater` updates the configuration file for the *DTN IP Neighbor Discovery Protocol (IPND)* deamon on each ION-DTN startup to represent the configuration by the user in the *SettingsActivity*. It uses the configuration values provided by the calling function and writes them in the file that is then used by the `IPND` deamon on startup.

### NativeAdapter

The `NativeAdapter` is (for most cases) the link between the components of the Android app and the JNI native code interface. This indirection allows the clustering of similar requests and improves maintainability.

In addition, the `NativeAdapter` provides a static file, read/write functionality and a subscriber system for managing ION-DTN instances status changes. This helps ensuring that service and GUI elements are always in sync with the underlying functionality.

### ReceiverRunnable

The `ReceiverRunnable` is instantiated by the `BundleService` whenever a receiver subscription for a particular `EID` is received. The receiving procedure in ION-DTN requires a thread actively waiting for a semaphore that is signaling an incoming bundle. Therefore, the `ReceiverRunnable` threads are mostly locked. The waiting for an incoming bundle has a timeout of 1 second. This is to ensure that  the `ReceiverRunnable` is interrupted and stopped within a reasonable timeframe after a `unsubscribing` for that particular `EID` has been received.
