# ION Interaction - JNI

The [Java Native Interface (JNI)](https://docs.oracle.com/javase/7/docs/technotes/guides/jni/) allows the interaction between the Android Java application code and the ION-DTN code written in the C programming language.

#### Declaration

In order to call a native function (i.e. C function) from the Android code you have to declare the native function in your java class.

```java
private native String stopION();
```

#### Native (Wrapper) functions

This **native** function call is then resolved in a C wrapper function that resides in the `jni` directory of the ION-DTN folder structure.

In case of `stopION`, the wrapper function can be found in `iondtn_administration.c`:

```java
/*
 * Stops running nodes.
 */
JNIEXPORT jstring JNICALL
Java_gov_nasa_jpl_iondtn_backend_NativeAdapter_stopION(JNIEnv *env,
                                                       jobject this)
{

    char	cmd[80];
    char	*result = "Node stopped";
    int 	count;

    // Ensure that all receiving threads that are using ION functionality got
    // notice of the shutdown and are no longer dependent on it --> prevents
    // crashes
    snooze(5);

    if (ipnd_pid != -1) {
        sm_TaskKill(ipnd_pid, SIGTERM);
        __android_log_write(ANDROID_LOG_DEBUG, "STOP", "Stopped the IPND threads");
        ipnd_pid = -1;
    }

    ...

    snooze(1);
    return (*env)->NewStringUTF(env, result);
}
```
The name of the native wrapper function has to follow this very specific naming pattern in order to be resolvable by the JNI. You can use Android Studio's **Autogeneration tool** (just hover over a nonexisting native function) to create the function and most of the housekeeping automatically.

#### Memory Management

Java usually uses a *Garbage Collector* to ensure that the memory management is sound. However, Java cannot use it's *Garbage Collector* for the native functions. This means that the programmer of native wrapper functions has to ensure that the memory allocation (in particular of function parameters and return values) is correct and consistent.

```java
JNIEXPORT jboolean JNICALL
Java_gov_nasa_jpl_iondtn_gui_AddEditDialogFragments_ContactDialogFragment_deleteContactION(
        JNIEnv *env, jobject instance, jstring timeFrom_, jstring nodeFrom_, jstring nodeTo_) {
    const char *timeFrom = (*env)->GetStringUTFChars(env, timeFrom_, 0);
    const char *nodeFrom = (*env)->GetStringUTFChars(env, nodeFrom_, 0);
    const char *nodeTo = (*env)->GetStringUTFChars(env, nodeTo_, 0);
```

Whenever string variables are used as function parameters, these Java strings have to be converted to char types in order to use them within the native C code. Simple data types as integers and chars can be used without conversion.

After using the converted variables in the native code and before returning, the native function has to release the memory allocated during the conversion. T

```java
(*env)->ReleaseStringUTFChars(env, timeFrom_, timeFrom);
(*env)->ReleaseStringUTFChars(env, nodeFrom_, nodeFrom);
(*env)->ReleaseStringUTFChars(env, nodeTo_, nodeTo);
```

Return values have to be transferred to the memory space where the Java *Garbage Collector* is responsible. This can be done by:

```java
return (*env)->NewStringUTF(env, result);
```

> **Important:** The return variable and, possibly, still used and previously provided parameters are the only variables that should endure the lifetime of the function. All other local variables have to be freed before returning to the Java code.
