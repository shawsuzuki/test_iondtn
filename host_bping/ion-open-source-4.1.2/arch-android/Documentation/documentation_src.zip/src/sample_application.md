# Sample Applications

Besides the project developed in the chapter ["Hello World"](hello_world.md) there is another documented demo application available called "minimalTextApplication" and "CameraShare".

The sample applications might be helpful when developing an own application that should also include receiving functionality or that is sending/receiving large chunks of data.

## MinimalTextApplication

The app "minimalTextApplication" can be found under `arch_android/demo_applications/minimalTextApplication`. It is more sophisticated than the "Hello World" example. It allows both sending and receiving text as bundles and comes with a GUI that lets the user choose both the payload and the destination EID.

## CameraShare

The app "CameraShare" (`arch_android/demo_applications/CameraShare`) uses the Android's devices camera to take pictures and then sends these pictures to an specific EID. When the "CameraShare" application is at the receiving side, it displays the received images in a gallery.

The app is compatible with ION's `bpsendfile` and `bprecvfile` command line tools (so you can take pictures on your phone and send it to your PC). This app is particularly helpful if you want to use the `FileDescriptor` functionality of the interface.
