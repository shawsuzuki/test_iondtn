# IonDTN Provider Application

This chapter will give an detailed insight into the architecture of the *IonDTN* provider application and will explain many design choices.

This might be particularly helpful when the application has to be updated to interact with newer versions of Android or ION-DTN.

The chapter [Overview](iondtn_overview.html) provides a general architectural overview of the app. The chapter [ION Integration - JNI](iondtn_jni_interaction.html) explains details about the way that the legacy C code of ION-DTN was integrated into the Java Environment.

The [Services](iondtn_services.html) chapters introduce the two internal and external services and their functions. Furthermore, some details about the Android Service Lifecycle Management and the imposed restrictions are explained in the chapter [Lifecycle Management](iondtn_services_lifecycle_management.html). The chapters in the section [GUI](iondtn_gui.html) explain how the GUI is designed and what hereditary dependencies exist. In [Backend](iondtn_backend.html) some internal classes and their important functions are presented and [Types](iondtn_types.html) contains a brief introduction into the types that are included in the application and that represent certain ION-DTN objects.
