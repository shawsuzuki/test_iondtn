# Overview

The IonDTN follows the Android Design Guidelines and is structured in a encapsulated manner. The overall architecture is depicted in the following image:

![iondtn setup welcome](./resources/iondtn_architecture.png)

The provider application consists of 3 main components:
- the GUI elements,
- the `NodeAdministrationService` and
- the `BundleService`.

The communication betweeen these main components is (mostly) realized through Android's [IBinder IPC framework](https://developer.android.com/reference/android/os/Binder.html). Furthermore, sometimes callback and listening functionality is realized by direct calls via interface implementations.

### GUI
The GUI provides an interface to start and stop the underlying native ION-DTN instance and also allows the configuration of the ION-DTN node by the user.

The GUI uses both the `NodeAdministrationService` to perform configuration and maintenance operations. It consists of multiple actions and fragments that are alsways handling a specific aspect of the ION-DTN instance (e.g. configuring the ION-DTN contacts or starting/stoping the instance).

More details about the GUI structure and existing dependencies/inheritance structures can be found in the [GUI](iondtn_gui.html) chapters.

### NodeAdministrationService

The `NodeAdministrationService` is not accessible from the outside (i.e. other Android applications). It's sole purpose is the configuration and lifecycle management of the underlying ION-DTN instance. This configuration is done through the NativeAdapter/JNI interface.

### BundleService

The `BundleService` provides all necessary functionality to send and receive data and is therefore propagated to other applications via the operating system. Other applications then can request a handle for the Service by explicitly addressing the service:

```java
// Bind to service
Intent serviceIntent = new Intent()
       .setComponent(new ComponentName(
               "gov.nasa.jpl.iondtn",
               "gov.nasa.jpl.iondtn.services.BundleService"));
```

The `BundleService` internally uses the the NativeAdapter/JNI interface to communicate with the ION-DTN instance. Furthermore, it uses the IBinder framework to communicate with the `NodeAdministrationService` to perform necessary configuration operations.

### NativeAdapter

The `NativeAdapter` class provides an internal abstraction layer of Java's [Java Native Interface (JNI)](https://docs.oracle.com/javase/7/docs/technotes/guides/jni/). This allows the reutilization of core functionality by multiple other application components (i.e. both `BundleService` and `NodeAdministrationService`) and simplifies the necessary function calls by hiding JNI-specific housekeeping tasks.
