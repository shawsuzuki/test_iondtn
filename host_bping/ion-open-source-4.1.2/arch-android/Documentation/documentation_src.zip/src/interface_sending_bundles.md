# Sending Bundles

The Service "BundleService" provides a function that can be used to trigger ION to send out a bundle with a given payload:

```java
// Send provided data, the payload is encapsulated in the DtnBundle object or provided as a file references
boolean sendBundle(in DtnBundle b);
```

### Sending a byte array

```java
/**
 * Constructor that allows the instantiation of a DtnBundle with a ByteArray.
 * @param eid The source EID
 * @param creation_time The time that the DtnBundle was created. Is ignored
 *                      when DtnBundle is sent.
 * @param time_to_live The time-to-live value that the DtnBundle had when
 *                     being received by ION-DTN
 * @param priority The priority class of the DtnBundle (Bulk, Standard,
 *                 Expedited)
 * @param payload_byte_array The raw payload as byte array.
 */
public DtnBundle(String eid,
                 long creation_time,
                 int time_to_live,
                 Priority priority,
                 byte[] payload_byte_array) {
...
```

For small sizes the payload can be handed over to ION as a byte array. The conversion of intrinsic variable types to a byte array is very easy, e.g. for Strings this can be accomplished by the following code snippet.

```java
String s = new String("This is a string!");
ByteArray b;

try {
    b = s.getBytes("UTF-8")
}
catch (UnsupportedEncodingException e) {
    // ... catch error here ...
}
```

Besides the payload parameter, the constructor of `Bundle` also requires the destination identifier (EID) as a string, the Time-to-Live and a quality-of-service parameter as an int.

The available quality-of-service classes are defined as an enum with the following values:

```java
// The priority class of the (sending) bundle, invalid for received bundles
public enum Priority {BULK, STANDARD, EXPEDITED, INVALID}
```

The `ByteArray` constructor is feasible for small portions of data, however, if the data size increases, the usage of *FileDescriptors* is recommended. The reason for this is the overall size limitation for IPC data in Android. As of now, Android limits the transaction size to 1 MB in total[^1]. This means that all applications running on an Android device have to share this small amount of memory. The limit might be increased in the future, but considering the back compatibility to older devices and Android versions, using as little memory as possible is recommended.

> **Note:** Using the IPC memory in an excessive way cannot be prevented from IonDTN as it just gets the information about the size of the payload when the data has already been stored in the reserved memory region. However, if the IPC memory is exhausted, the IPC call will fail before even reaching IonDTN.

### Sending a file descriptor

```java
/**
 * Constructor that allows the instantiation of a DtnBundle with a
 * {@link ParcelFileDescriptor}.
 * @param eid The EID
 * @param creation_time The time that the DtnBundle was created. Is ignored
 *                      when DtnBundle is sent.
 * @param time_to_live The time-to-live value that the DtnBundle had when
 *                     being received by ION-DTN.
 * @param priority The priority class of the DtnBundle (Bulk, Standard,
 *                 Expedited)
 * @param payload_fd The {@link ParcelFileDescriptor} pointing to the
 *                   payload of the DtnBundle.
 */
public DtnBundle(String eid,
                 long creation_time,
                 int time_to_live,
                 Priority priority,
                 ParcelFileDescriptor payload_fd) {
...
```

In order to send larger portions of data, the constructor of `DtnBundle` allows the handover of a file descriptor. This file descriptor is of the type `ParcelFileDescriptor` because it has to be transparent to the Android OS.

The procedure for using `sendFile` is as follows:

#### Create File
Create a new file or open an existing one in your app. This will give you a `FileDescriptor` for that file.
```java
  File f = new File(...);
  FileOutputStream fos = new FileOutputStream(f);
```
#### *(Optional) Write data to file*
You can then create a `FileOutputStream` for that file and use the `write` method of the `FileOutputStream` to write your data into the file. If your file already contains the data that you want to send you can skip this step.
```java
  FileOutputStream fos = new FileOutputStream(f);
  fos.write(<data>);
  fos.close();
```

#### Open a ParcelFileDescriptor for your file
Open a `ParcelFileDescriptor` based on your file:
```java
  ParcelFileDescriptor pfd = ParcelFileDescriptor.open(f,
                        ParcelFileDescriptor.MODE_READ_ONLY);
```
The `pfd` object now holds a reference to your file that can be sent to *IonDTN* via IPC and that allows it to read the data of the file.

#### Create `DtnBundle` object
By calling the previously shown constructor, you can then create a Bundle object referencing the source file by holding the ParcelFileDescriptor `pdf`.

```java
DtnBundle b = new DtnBundle(destEID,
                            0,
                            300,
                            DtnBundle.Priority.EXPEDITED,
                            pfd);
```

#### Call *IonDTN*
Now you can hand over the `DtnBundle` object holding the `ParcelFileDescriptor` object by calling the `sendBundle` function. As all `AIDL` IPC calls are executed synchronously, *IonDTN* will read the data from the file and when the IPC call returns you can simply close the `file` and the `ParcelFileDescriptor`.

> **Note:** Using a file descriptor rather than a file object itself even allows the transmission of file content that is residing in the clients private application memory and would otherwise be inaccessible to *IonDTN*.

## Source EID

As introduced in the Chapter [Receiving Bundles](interface_receiving_bundles.html), client applications can open endpoints in ION via the `BundleService` interface. Whenever an endpoint is opened for a specific client application, all bundles from that client application have the opened EID as source EID. If no endpoint is open (like in our *Hello World* example) the source EID `dtn:none` is used. This behaviour corresponds to the behaviour of the ION-DTN shell tool `bpsend`.

-----------------
*[1] https://stackoverflow.com/questions/38175781/android-ipc-maximum-transaction-size*
