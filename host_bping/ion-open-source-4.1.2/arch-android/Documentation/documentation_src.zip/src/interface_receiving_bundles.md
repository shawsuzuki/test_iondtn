# Receiving Bundles

The two key functions for receiving data from the *IonDTN* application are listed in the following code snippet:

```java
// Open an endpoint object with the specified source eid
boolean openEndpoint(String src_eid, IBundleReceiverListener listener);

// Close the previously opened endpoint object
boolean closeEndpoint();
```

The process of receiving the payload of bundles addressed to the own EID follows the [publisher/subscriber software pattern](https://en.wikipedia.org/wiki/Publish%E2%80%93subscribe_pattern) and consists of multiple steps. The payload can only be received if the client application has previously registered for the particular EID as a listener.

### IBundleReceiverListener

The registering can be done by calling the function `registerListener`. As a parameter for that, the client application has to implement the interface `IBundleReceiverListener` as defined in the `aidl` file:

```java
// IBundleReceiverListener.aidl
package gov.nasa.jpl.iondtn;

import gov.nasa.jpl.iondtn.Bundle;

interface IBundleReceiverListener {
    /**
     * Is called when a bundle assigned to the subscribers eid has been
     * received in ION
     */
    int notifyBundleReceived(in Bundle b);
}

```

Whenever a bundle is received for the registered EID, the function of the implemented interface is called. If the payload is very small, the function returned `Bundle` object contains an ByteArray with the payload. However, if the payload exceeds a certain threshold, the `Bundle` containing a `ParcelFileDescriptor` pointing to a file with the data. The payload type of a particular bundle can be determined by the enum field `type` of `Bundle`. It is either `BYTE_ARRAY` or `FILE_DESCRIPTOR`.

> **Note:** The size threshold for switching from `BYTE_ARRAY` to `FILE_DESCRIPTOR` is defined as an integer value (representing bytes) in the settings of  `IonDTN` and can be changed via the GUI. Simply open the main navigation drawer, select "Settings" and then "General".

An implementation of the listener interface can be done within the calling class of the client application.

The following example is an showing how the interface can be implemented if the payload bytes are representing text encoded in UTF-8.

```java
IBundleReceiverListener.Stub listener = new IBundleReceiverListener.Stub() {

        @Override
        public int notifyBundleReceived(gov.nasa.jpl.iondtn.Bundle b) throws RemoteException {
            if (b.getPayloadType() == gov.nasa.jpl.iondtn.Bundle.payload_type
                    .BYTE_ARRAY) {
                try {
                    received += "Source: " + b.getEID() + " Payload: ";
                    received += new String(b.getPayloadByteArray(), "UTF-8");
                    received += "\n";

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textViewReceive.setText(received);
                        }
                    });
                }
                catch (UnsupportedEncodingException e) {
                    Log.e(TAG, "notifyBundleReceived: UTF-8 encoding is not " +
                            "supported on this device");
                }
            }
            else {
                String line;

                FileInputStream in = new FileInputStream(b.getPayloadFD()
                        .getFileDescriptor());
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                try {
                    while ((line = br.readLine()) != null) {
                        received += "Source: " + b.getEID() + " Payload: ";
                        received += line;
                        received += "\n";
                    }
                }
                catch (IOException e) {
                    Log.e(TAG, "notifyBundleReceived: Failed to parse file referenced " +
                            "by file descriptor");
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewReceive.setText(received);
                    }
                });
            }

            return 0;
        }
};
```
The return values of the function signal the success or failure of the reception process to the *IonDTN* application and have to follow the POSIX standard.

> **Note:** Currently, the return values are not evaluated and thus the received data is discarded after the IPC call. This is to ensure that the memory management is sound.

### Open Endpoints

When having implemented the `IBundleReceiverListener` interface the client application can then register at the *IonDTN* application to receive the payload of bundles addressed to one (or more) EIDs of the local node.

In order to register, the client application has to call

```java
// Open an endpoint object with the specified source eid
boolean openEndpoint(String src_eid, IBundleReceiverListener listener);
```

The parameters are defined as follows:
- *src_eid*: A local EID that the client wants to receive the payload of incoming bundles from. (This eid is also used for sent out bundles of the particular client application after the endpoint has been opened).
- *listener*: The implemented `IBundleReceiverListener` interface.

After the `openEndpoint` IPC function call, whenever bundles are received that are addressed to the registered EID, the *IonDTN* application is calling the appropriate receiver function of the client application.

### Close Endpoints

If the client application no longer wants to receive the payload of bundles addressed to a certain EID, it can call the unregistering routine:

```java
// Close the previously opened endpoint object
boolean closeEndpoint();
```

This unregisters the `IBundleReceiverListener` interface and sent out bundles have `dtn:none` as source eid again.
