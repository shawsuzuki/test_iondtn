<img src="./resources/icon_ion.png" width="150" height="150" />
## IonDTN - A DTN Provider Application for ANDROID

## Introduction

Thank you for your interest in [ION-DTN] and the IonDTN Android application!

This documentation will help you getting started with developing client applications that use the IonDTN provider application to communicate with other DTN nodes.

Furthermore, this documentation contains information about the structure of the IonDTN application and the design decisions that were taken during the development process. This might be helpful when modifying or maintaining the app.

## Table of Contents

This documentation is split into multiple parts. After this introduction, the chapter [Requirements] contains details regarding required development files and toolchains. [Chapter 3] gives a brief introduction in how to develop a minimal Android application that uses IonDTN. Subsequently, [Chapter 4] gives a detailed description of the interface that IonDTN provides.

While reading the chapters 1-4 are sufficient in order to develop DTN-enhanced applications, [Chapter 5] and [Chapter 6] are giving a detailed insight into the architecture and operating principles of the provider application and the provided sample applications.

[ION-DTN]: https://sourceforge.net/projects/ion-dtn/
[Requirements]: requirements.html
[Chapter 3]: getting_started_main.html
[Chapter 4]: interface_main.html
[Chapter 5]: architecture_provider_main.html
[Chapter 6]: sample_application_main.html
