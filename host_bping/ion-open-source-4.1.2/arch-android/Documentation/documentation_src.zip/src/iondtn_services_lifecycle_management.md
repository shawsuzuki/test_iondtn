# Lifecycle Management

## Lifecycle

Android provides two different service concepts:

#### On-Demand
 The service is started and stopped whenever another application on the device requests it. Multiple applications can use the service at the same time but as soon as all clients have disconnected, the service will shutdown. As soon as a new client requests the service, it is started again. The *subscription* process is realized by *binding* through the IBinder framework:
 1. The client requests the service from the OS,
 2. the OS request a handle for the service from the service itself
 3. the OS hands this handle to the client.

#### Continuous
Instead of starting and stopping the service upon client requests, in the case of the **continuous** concept the service is started by the application providing the service itself (or whenever the first client request is received). The key difference to the `on-demand` concept is that the service will not be shutdown when the last client disconnects but rather continues running in the background until a new request is received. This approach is required when startup or shutdown of service structures may take very long.

## Foreground Execution

Android is very restrictive in regards of resource management and thus limits the way and the duration that applications can run in the background. This also includes the service components of an application.

If an application is moved to the background (e.g. when the user is switching to another application) all components of the application will eventually get stopped (whenever the operating systems deems appropriate). For a provider application like **IonDTN** this shutdown prevents proper functioning. The native code part in particular needs a stable, long-running environment and the startup and shutdown times in the order of multiple seconds render frequent status changes unfeasible.

Android provides a way to prevent unwanted shutdowns by the OS, the start of a service in the **foreground**-mode. This foreground mode displays a continuous (non-dismissable) notification in the notification center of Android:

![iondtn notification](./resources/ion_dtn_notification.png)

In case of IonDTN this notification shows the current status of the underlying native ION-DTN instance and is visible as soon as the status of the instance is different than `stopped`. Other possible statuses are `starting`, `started` and `stopping`. This status output allows the user to easily check the status at any given time, even if the application is not in the foreground. The notification remains in the notification center until the ION-DTN instance is stopped again.

The display of the continuous notification in the foreground will render the chance that Android is killing the service associated to the notification extremely unlikely.

More information about the `startForeground()` functionality can be found at [this link](https://developer.android.com/guide/components/services.html#Foreground).
