# BundleService

The `BundleService` provides the interface and communication structures and methods that render communication between the client applications on the Android device and the native ION-DTN instance possible.

### Registering with the Operating System
As the service has to be accessible from outside of the application scope, the `AndroidManifest.xml` project file has to include a reference to this service. This ensures that the service is registered correctly with the operating system and that subsequently client applications can bind to the service by sending a request to to the OS.

```xml
...
<service
    android:name=".services.BundleService"
    android:exported="true"
    android:label="@string/app_name"/>
...
```

The manifest registration contains the name of the service as well as the explicit command to export the service and thus make it available from the outside.

### Operation Type

As the `BundleService` is using the underlying ION-DTN instance, the operation type has to be *continuous* (please refer to [Lifecycle Management](iondtn_services_lifecycle_management.html) for details). Starting and stopping ION-DTN frequently would reduce the availability of the service significantly and would render real-world usage impossible.

### Core Functionality

The service itself implements the interface functionality laid out in the `IBundleService.aidl` file. Most of the functionality is already described in the [Interface](interface.html) chapters. Besides the visible functionality, the `BundleService` is also managing the listener management by starting and stopping `ReceiverRunnable` runnables when necessary. Details about the `ReceiverRunnable` can be found in the chapter [Backend](iondtn_backend.html).
