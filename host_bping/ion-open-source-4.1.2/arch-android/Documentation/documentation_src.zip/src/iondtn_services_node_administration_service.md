# NodeAdministrationService

The `NodeAdministrationService` serves the purpose of providing configuration management functionality to internal application components like the GUI elements.

### Why only internally?
This functionality should only be available to the user via the GUI and not to be modified by the client applications. This is to ensure a consistent configuration at any time. There might be multiple clients running at the same time that want to configure the node differently. No proper long-term configuration exclusion can be provided (which in turn would render the usage by other client applications impossible). Also, multiple concurrently running ION-DTN instances would contradict the daemon concept and exhaust the resources of many Android devices.

In conclusion, a proper configuration can only be ensured on a node-level and not on an application-level. Therefore only the user can configure the node. This is consistent with the way that nodes and their protocol stack is managed in nowadays internet. In the long run there might be additional DTN functionality that allows the auto-configuration of the node comparable to the Internets `DHCP`. ION-DTN already provides an **DTN IP Neighbor Discovery Protocol (IPND)** that (when activated and configured) automatically detects neighboring nodes and sets up contacts/ranges/inoutducts accordingly.

### Registering with the Operating System
Like the `BundleService`, the `NodeAdministrationService` also has to be registered with the Operating System through the `AndroidManifest.xml` project file:

```xml
...
<service
    android:name=".services.NodeAdministrationService"
    android:exported="false"/>
...
```

However, as the `NodeAdministrationService` shall only be accessible from the inside, the service is not exported. Besides that the service is bound by internal components in the same way as client application bind to the `BundleService`.

### Core Functionality

The `NodeAdministrationService` provides functionality to start and stop ION-DTN. These functions are run in `AsyncTasks` to prevent lag effects in the GUI.

> **Note:** It is important to notice that despite being regarded as different components in the *Android Application Architecture*, the GUI and all services are still running in the same thread. Therefore, computation-expensive operations should be outsourced by e.g. using `AsyncTask`.

Besides start and stop, the `NodeAdministrationService` also provides request functions for all relevant components of ION-DTN. Such requests can e.g. be getting all contacts currently scheduled in ION-DTN. The requests are handed to to the `NativeAdapter` (see chapter [Backend](iondtn_backend.html)) and then resolved by the JNI native application code. The return value of all these functions is a String that then has to be parsed to application objects (see chapter [Types](iondtn_types.html)). Please refer to the chapter [Ion Interaction - JNI](iondtn_jni_interaction.html) on why returning a string is more effective than returning a more complex object.

The actual object operations (like adding/removing/editing) are performed directly in the GUI's edit dialogs and these operations communicate with the JNI layer without the involvement of the `NodeAdministrationService`. This is to remove the (unnecessary) indirection of calling `NodeAdministrationService` and `NativeAdapter` and also reduces the complexity of these function calls.
