# Interface

This chapter will introduce the functionality that is provided by the *BundleService* of the *IonDTN* application in more detail.

The basis for communicating with the *BundleService* is a proper binding to the client application. Only after the binding process has been completed successfully the sending/receiving procedures can be invoked.

> **Note:** Please refer to the chapter ["Binding to IonDTN"](hello_world_binding_iondtn.html) for more details on the binding process.

The chapter ["Sending Bundles"](interface_sending_bundles.html) introduces the sending routines that the interface provides and the chapter ["Receiving Bundles"](interface_receiving_bundles.html) explains how a listener mechanism for receiving bundles can be established.
