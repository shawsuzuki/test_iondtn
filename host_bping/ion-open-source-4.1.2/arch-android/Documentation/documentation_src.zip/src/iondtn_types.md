# Types

In the package `gov.nasa.jpl.iondtn.types` various types are implemented that represent a particular configurable object in the ION-DTN scope:
- DtnBabRule
- DtnBcbRule
- DtnBibRule
- DtnConfidence
- DtnContact
- DtnDataRate
- DtnEidScheme
- DtnEndpointIdentifier
- DtnInOutduct
- DtnKey
- DtnProtocol
- DtnRange
- DtnTime

All these types are used when data received from the JNI layer is received and parsed. The representation as these objects is then used when populating the RecyclerViews of the GUI and when calling the *EditDialogs* for a paticular object. In order to allow the passage of a particular object to an *EditDialog* (which is basically another Activity), all `Dtn*` objects are implementing the `Parcelable` interface to correspond with the Android guidelines.

All types have dedicated unit tests implemented in `gov.nasa.jpl.iondtn.types`.
