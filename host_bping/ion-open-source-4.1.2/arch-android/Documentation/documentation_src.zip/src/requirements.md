# Requirements
Requirements depend on whether you have IonDTN already installed on your device, i.e. through
- Google Play,
- A third-party app store or
- By installing an `.apk`-archive.

If that is the case, you only need the basic software elements. If you also have to build the IonDTN application, additional components are necessary.

> **Note:**
> If you are using IonDTN from a third-party platform, please ensure that the app version version is corresponding to this documentation. Otherwise, you might end up with a malfunctioning interface interaction.

### Requirements for the client applications
#### Android Studio
[Android Studio] is the official IDE for Android and although there are also other IDEs for Android development, Android Studio is the way to go. Therefore, this documentation is assuming that you are using Android Studio when describing tasks.

Android Studio is available for free for Windows, Mac and Linux and can be downloaded at the linked website.

#### Android SDK

The Android Software Development Kit (SDK) contains the actual source code that is used to compile your application into an installable `.apk` archive. As the source code and the operating system interfaces vary between Android versions, you need to have the appropriate SDK version installed on your development machine. Usually, Android Studio handles the installation itself and just asks you for permission to install the correct version. However, if that is not the case, you can always check and install different versions in Android Studio at `Tools -> Android -> SDK Manager`.

![SDK_Manager]

### Requirements for the provider application
#### Android NDK
The Android Native Development Kit (NDK) is required to interact with native code, in this case written in the programming languages C and C++. In order to use existing ION-DTN components, the NDK has to be installed on the development machine to build the provider app.

You can install the NKD via the Android Studio at `Tools -> Android -> SDK Manager (Tab SDK-Tools)`.

![ndk_install]

Additionally, if you integrate the NDK by adding the following lines to your `build.gradle` file, Android Studio will ask you about installing the NDK:

```
externalNativeBuild {
    ndkBuild {
        path "<Path to your Android.mk file>"
    }
}
```

You can find more details on how to use the NDK in the chapter [JNI Interaction](iondtn_jni_interaction.html).

[1]: #requirements-for-the-client-applications
[2]: #requirements-for-the-provider-application
[Android Studio]: https://developer.android.com/studio/index.html
[SDK_Manager]: ./resources/sdk_manager.png
[ndk_install]: ./resources/ndk_install.png
