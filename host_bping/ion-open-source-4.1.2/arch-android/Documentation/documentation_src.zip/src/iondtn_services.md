# Services

As depicted in the diagram in the chapter [Overview](iondtn_overview.html), the IonDTN Android application runs multiple services to provide functionality to both internal and external components. This is in line with the Android design guidelines and ensures a proper encapsulation.

The chapter [Lifecycle Management](iondtn_services_lifecycle_management.html) covers some special characteristics of services that are relevant in the context of running as a background function provider.

The subsequent chapters [BundleService](iondtn_services_bundle_service.html) and [NodeAdministrationService](iondtn_services_node_administration_service.html) provide some insight into the specific implementations of the services.
