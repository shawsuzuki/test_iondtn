# Binding to IonDTN

> **Note:** The entire *DtnHelloWorld* project can be found at `arch_android/Demo_Applications/IonHelloWorld`. Instead of extracting all the code snippets from this tutorial you can simply open/copy it and then continue reading.

As next step, we will write the source code to bind the `BundleService` provided by the *IonDTN* app to our own application.

The following picture depicts the interaction between our app *DtnHelloWorld* and *IonDtn*:

![interaction iondtn dtnhelloworld](./resources/interaction_iondtn_dtnhelloworld.png)

It becomes obvious that binding and unbinding from the `BundleService` is a very important part of the communication process.

## Android Interface Description Language (AIDL)

Android has very strict rules in regards of inter-process/inter-app communication. Therefore, all communication has to follow a certain pattern that the OS can evaluate. In practice, every interface is defined by a so-called `.aidl` file. This file is written in the *Android Interface Description Language (AIDL)*. Android Studio will use this file to create actual Java source code for resolving and responding to communication requests.

You can find out more about AIDL at this [link](https://developer.android.com/guide/components/aidl.html).

As the `BundleService` is already implemented in *IonDTN*, you don't have to implement the AIDL file yourself. Instead, just create three `.aidl` files with the names `IBundleService.aidl`, `IBundleReceiverListener.aidl` and `DtnBundle.aidl` and copy the contents in there.

![add aidl file](./resources/hello_world_add_aidl_file.png)

The next time that you are building (`Build -> Build Project`) or running the project, Android Studio will create the Java code and you are ready to use the interface functionality specified in the `.aidl` file. The functions are then also available via autocomplete.

### IBundleService.aidl

The first of the thre `.aidl` files you copied earlier is the interface specification of the actual `BundleService`:

```java
// BundleService.aidl
package gov.nasa.jpl.iondtn;

import gov.nasa.jpl.iondtn.IBundleReceiverListener;
import gov.nasa.jpl.iondtn.DtnBundle;

interface IBundleService {
    // Open an endpoint object with the specified source eid
    boolean openEndpoint(String src_eid, IBundleReceiverListener listener);

    // Close the previously opened endpoint object
    boolean closeEndpoint();

    boolean sendBundle(in DtnBundle b);
}

```
You can see that three different interface functions are defined. What these functions do will be covered later. For now, it is only important that the `IBundleService.aidl` exists in the *DtnHelloWorld* project.

### IBundleReceiverListener.aidl

As you may have noticed, the `IBundleService.aidl` file has the line:
```java
import gov.nasa.jpl.iondtn.IBundleReceiverListener;
```
Also, one of the function uses `IBundleReceiverListener` as a parameter. The reason for this is that there has to be a feedback path to notify the subscribed app about received bundles. A constant polling by the app is not very efficient. The solution is a listener interface that the calling app (i.e. DtnHelloWorld) creates and provides to the *IonDTN* application:
```java
// IBundleReceiverListener.aidl
package gov.nasa.jpl.iondtn;

import gov.nasa.jpl.iondtn.DtnBundle;

interface IBundleReceiverListener {
    /**
     * Is called when a bundle assigned to the subscribers eid has been
     * received in ION
     */
    int notifyBundleReceived(in DtnBundle b);
}
```
The interface defines one callback (receiving) function. As we are not implementing any receiving functionality in the DtnHelloWorld application, this functions is not relevant yet. You can find out more about how to send bundles in the chapter ["Sending Bundles"](interface_sending_bundles).

### DtnBundle.aidl and DtnBundle.java

Again, in `IBundleReceiverListener.aidl` the Type `DtnBundle` is used:
```java
import gov.nasa.jpl.iondtn.Bundle;
...
int notifyBundleReceived(in DtnBundle b);
```
This type is necessary to be able to use a custom object containing both the payload and additional bundle metrics (e.g. the source EID).

In order to use the `DtnBundle` type you have to add the following content to `DtnBundle.aidl`:

```java
// IBundle.aidl
package gov.nasa.jpl.iondtn;

parcelable DtnBundle;
```

The only thing happening in this file is that Bundle is defined as *parcelable*, i.e being suitable for transmitting across process boundaries via IPC.

To allow client applications to use the Bundle object, additionally the `gov.nasa.jpl.iondtn.DtnBundle.java` file (provided [here](./resources/code/DtnBundle.java)) has to be added to the project. You can achieve this by first adding a new package `gov.nasa.jpl.iondtn` and then adding the `DtnBundle.java` source file in that package.

## Binding

Now that the interfaces are defined, we can implement the binding process.

The binding process itself is consisting of two steps. First, *DtnHelloWorld* has to request the service from the Android OS. This is accomplished by sending out an intent which requests the `BundleService` component of *IonDTN*.

As we want to connect to the service as soon as we are starting our application, we send out the intent when the app is started, i.e. in `onStart()`:

```java
@Override
protected void onStart() {
    super.onStart();
    if (mService == null) {
        Log.d(TAG, "onStart: (Re-)Binding service");
        // Create Intent
        Intent serviceIntent = new Intent()
                .setComponent(new ComponentName(
                        "gov.nasa.jpl.iondtn",
                        "gov.nasa.jpl.iondtn.services.BundleService"));
        // Request to bind the service based on the intent
        bindService(serviceIntent, mConnection, BIND_AUTO_CREATE);
    }
}
```
> **Note:** There are different states that an Android activity can have and depending on that state, different functions (e.g. `onCreate()` or `onStart()`) are called. You can find out more about the activity lifecycle at this [link](https://developer.android.com/guide/components/activities/activity-lifecycle.html).

We have to select the service we want to connect to by explicitly specifying its name, in our case `"gov.nasa.jpl.iondtn.services.BundleService"` of the component `"gov.nasa.jpl.iondtn"`. This ensures that we connect to the right interface and that the other app understands what we want when calling an interface function.

The objects that are used in `onStart()` are also defined in MainActivity:

```java
// Tag for debug logging purposes
public static final String TAG = "MainActivity";
```
The tag is just for logging purposes and allows you to determine which part of your application has emitted a certain log message.

```java
// BundleService object
private gov.nasa.jpl.iondtn.IBundleService mService;
```
The `mService` object holds the interface information. This object was created automatically when you included the *AIDL* file earlier.

```java
// Service connection object
private ServiceConnection mConnection = new ServiceConnection() {

    @Override
    public void onServiceConnected(ComponentName className, IBinder service) {
        ...
    }

    @Override
    public void onServiceDisconnected(ComponentName className) {
        ...
    }
};
```
Finally, we have the `ServiceConnection` object. It holds all information regarding the particular connection with the *IonDTN* application and implements two functions `onServiceConnected()` and `onServiceDisconnected()`. The first function is called when a service connection was established after an intent request. The latter function is the counterpart and is called whenever the service connection is shut down, i.e. when the application providing the service is shut down (that the latter function is called is not guaranteed by the Operating System).

First, lets implement the `onServiceConnected()` method:
```java
@Override
public void onServiceConnected(ComponentName className, IBinder service) {
    Log.d(TAG, "onServiceConnected: Service bound!\n");

    // Save the service object
    mService = gov.nasa.jpl.iondtn.IBundleService.Stub.asInterface(service);

    // Update GUI
    button.setEnabled(true);
    editText.setEnabled(true);
}
```
The function is called by the operating system with an `IBinder` object as parameter. We have to save this object as it allows us to use the service. Furthermore, we can now activate the `button` and `editText` to allow user interaction.

We should also output a log message if the service get disconnected. This can be done in the `onServiceDisconnected()` method:
```java
@Override
public void onServiceDisconnected(ComponentName className) {
    Log.d(TAG, "onServiceDisconnected: Service unbound!\n");
}
```

## Unbinding

When done using the service, our app *DtnHelloWorld* should close the connection to the service properly. This is relevant when the app is closed by the user. To close the service connection, we override the function `onStop()`:

```java
@Override
protected void onStop() {
    super.onStop();
    Log.d(TAG, "onStop: Unbinding service");

    // Only unbind if bound in the first place
    if (mService != null) {
        // Disable GUI
        button.setEnabled(false);
        editText.setEnabled(false);

        // Unbind service
        unbindService(mConnection);

        // Reset service element (GC will handle!)
        mService = null;
    }
}
```

We are only unbinding if a connection was established in the first place. As the establishing of a connection is realized asynchronously there is a chance that that never happened.

If we have a connection to close, we first disable the GUI and the call the OS unbinding function. After this function call we ensure that the garbage collection properly removes the old object by assigning `null` to `mService`.

## Imports

In order to use all components that we just copied into the application, we also have to make sure that the correct includes are used. These includes should be included in the header of the `MainActivity.java` file.

```java
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
```
