# Application Setup

First, we have to create a new application, design an graphical user interface (GUI) and grant the application some necessary system permissions.

> **Note:** The entire *DtnHelloWorld* project can be found at `arch_android/Demo_Applications/IonHelloWorld`. Instead of extracting all the code snippets from this tutorial you can simply open/copy it and then continue reading.

## Create a new project

Assuming that you have already installed Android Studio as described in the chapter ["Requirements"](./requirements.html), please open Android Studio and select `File -> New -> New Project`. A new dialog pops up where you can setup the new project:

![new project name](./resources/new_project_name.png)

We are calling the application "IonHelloWorld" and after clicking `Next` we can select the "Minimum SDK".

![new project target sdk](./resources/new_project_target_sdk.png)

Just use the standard settings and click `Next`.

![new project activity](./resources/new_project_activity.png)

In the following dialog we can pick a start activity. We're also going with the default selection here which is an "Empty Activity". Click `Next`.

![new project activity name](./resources/new_project_activity_name.png)

Finally, we have to pick a name for your activity. Accept the default and click `Finish` to create the project. Android Studio will now create all required files and change it's layout. After the creation process has finished, you can find all project files in the top left corner of the window.

![new project file explorer](./resources/new_project_file_explorer.png)

## Create the GUI

As next step we have to create a GUI that allows the user to enter a destination EID and trigger the sending process. For entering the destination EID we are going to use an `editText` object and for triggering the event a basic `button` object:

![hello world layout](./resources/hello_world_layout.png)

The code for this layout has to be put into `app/res/layouy/activity_main.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context="gov.nasa.jpl.ionhelloworld.MainActivity">

    <LinearLayout
        android:layout_width="368dp"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        tools:layout_editor_absoluteX="8dp"
        tools:layout_editor_absoluteY="8dp">

        <TextView
            android:id="@+id/textView"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:text="EID:"/>

        <EditText
            android:id="@+id/editText"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:ems="10"
            android:inputType="textPersonName"
            tools:layout_editor_absoluteX="82dp"
            tools:layout_editor_absoluteY="48dp"/>

        <Button
            android:id="@+id/button"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:text="Send"
            tools:layout_editor_absoluteX="145dp"
            tools:layout_editor_absoluteY="122dp"/>
    </LinearLayout>

</android.support.constraint.ConstraintLayout>
```
For details on how to create a (more sophisticated) activity layout, please refer to the [Android documentation](https://developer.android.com).

We now have an application that has a layout and that can be executed on any Android device.
You can test this by connecting an Android device to your development machine, enabling debugging in the device's settings and pressing the `Run 'app'` icon in the toolbar:

![run app](./resources/run_app.png)

## Disable GUI elements

As the last step of this chapter, we want to disable the GUI elements for user interaction, in particular the button and the editText elements. These elements should only be selectable when the `BundleService` is connected.

```java
@Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize parent class
        super.onCreate(savedInstanceState);

        // Inflate layout of activity
        setContentView(R.layout.activity_main);

        // Bind layout elements to Java objects
        button = (Button)findViewById(R.id.button);
        editText = (EditText)findViewById(R.id.editText);

        // Disable elements (until service is available)
        button.setEnabled(false);
        editText.setEnabled(false);

        // Define 'click' behavior for button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ...
            }
        });
    }
```
After initializing the parent class and inflating the layout, the layout elements have to be bound to Java object that can be used in the class. The two object should be available in other methods of this class, therefore they are defined class-wide and are just bound in the `onCreate()` function:

```java
public class MainActivity extends AppCompatActivity {
    Button button;
    EditText editText;
...
```
Besides disabling the elements we are also assigning an `OnClickListener` to the button object. The content of this listener is defined in the chapter ['Hello World'](hello_world_hello_world.html).
